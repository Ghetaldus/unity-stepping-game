// =======================================================================================
//
//
// =======================================================================================

using System;
using UnityEngine;
using UnityEngine.UI;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using Mono.Data.Sqlite;
using wovencode;

namespace wovencode
{

	// ===================================================================================
	// ENUMS
	// ===================================================================================
	public enum MeasurementSystem { Metric, Feet }

	// ===================================================================================
	// STEP DATA
	// ===================================================================================
	[System.Serializable]
	public class StepData
	{

		public int 					totalSteps 						= 0;
		public double 				totalDistance 					= 0;
		public double 				totalCalories 					= 0;
		public double				totalDuration 					= 0;
		
		protected int 					lastSteps 						= 0;
        protected double 				lastDistance 					= 0;
        protected int 					newSteps 						= 0;
        protected double 				newDistance 					= 0;
		
		protected List<SessionData> 	sessionData = new List<SessionData>();
		
		// -------------------------------------------------------------------------------
		// GetSteps
		// -------------------------------------------------------------------------------
		public int GetSteps() {
			return newSteps;
		}
		
		// -------------------------------------------------------------------------------
		// OnStep
		// -------------------------------------------------------------------------------
		public void OnStep(int steps, double distance)
		{
		
			if (sessionData.Count == 0) return;
		
            newSteps 			= steps 	- lastSteps;
            newDistance			= distance 	- lastDistance;
            
            totalSteps 			+= newSteps;
			totalDistance 		+= newDistance;
			totalCalories		= Tools.ConvertToCalories(totalSteps, SessionManager.instance.stepsDefault, SessionManager.instance.caloriesDefault);
			
			sessionData.Last().OnStep(newSteps, newDistance);
			
			lastSteps 			= steps;
            lastDistance 		= distance;
		}
		
		// -------------------------------------------------------------------------------
		// OnReset
		// -------------------------------------------------------------------------------
		public void OnReset()
		{
			if (sessionData.Count == 0) return;
			sessionData.Add(new SessionData());
			
			if (sessionData.Count > SessionManager.instance.maxSessions)
				sessionData.RemoveAt(0);
			
		}
		
		// -------------------------------------------------------------------------------
		// OnLoad
		// -------------------------------------------------------------------------------
		public void OnLoad()
		{

			sessionData = new List<SessionData>();
			
			List< List<object> > table = DatabaseManager.instance.ExecuteReader("SELECT steps, distance, calories, duration, timestamp FROM sessions WHERE id=@id", new SqliteParameter("@id", Tools.GetUserId));
			
			if (table.Count > 0) 
			{

				foreach (List<object> row in table)
				{
					SessionData session 	= new SessionData();
					session.steps 			= Convert.ToInt32((long)row[0]);
					session.distance 		= (float)row[1];
					session.calories 		= (float)row[2];
					session.lastDuration 	= (float)row[3];
					session.timestamp 		= (string)row[4];
					session.UpdateDuration();
					sessionData.Add(session);
				}
			
			}
			else
			{
				SessionData session 	= new SessionData();
				session.UpdateDuration();
				sessionData.Add(session);
			}
			
			UpdateTotals();
			
		}
		
		// -------------------------------------------------------------------------------
		// OnSave
		// -------------------------------------------------------------------------------
		public void OnSave()
		{
			
			DatabaseManager.instance.ExecuteNonQuery("DELETE FROM sessions WHERE id=@id", new SqliteParameter("@id", Tools.GetUserId));
			
			foreach (SessionData session in sessionData)
			{
				DatabaseManager.instance.ExecuteNonQuery("INSERT INTO sessions VALUES (@id, @steps, @distance, @calories, @duration, @timestamp)",
													new SqliteParameter("@id", 			Tools.GetUserId),
													new SqliteParameter("@steps", 		session.steps),
													new SqliteParameter("@distance", 	session.distance),
													new SqliteParameter("@calories", 	session.calories),
													new SqliteParameter("@duration", 	session.lastDuration),
													new SqliteParameter("@timestamp", 	session.timestamp)
													);
			}
			
		}
		
		// -------------------------------------------------------------------------------
		// UpdateTotals
		// -------------------------------------------------------------------------------
		public void UpdateTotals()
		{
			
			foreach (SessionData session in sessionData)
			{
				totalSteps 			+= session.steps;
				totalDistance 		+= session.distance;
				totalCalories		+= session.calories;
			}
			
		}
		
		// -------------------------------------------------------------------------------
		
	}

    // ===================================================================================
	// SESSION DATA
	// ===================================================================================
	[System.Serializable]
	public class SessionData
	{
		
		public string	timestamp		= "";							// permanent
		public int 		steps 			= 0;							// permanent
		public double 	distance 		= 0;							// permanent
		public double 	calories 		= 0;							// permanent
		public double 	lastDuration 	= 0;							// permanent
		
		public double	duration		= 0;							// temporary
		
		// -------------------------------------------------------------------------------
		// OnStep
		// -------------------------------------------------------------------------------
		public void OnStep(int newSteps, double newDistance)
		{
			steps 		+= newSteps;
			distance 	+= newDistance;
			calories 	= Tools.ConvertToCalories(steps, SessionManager.instance.stepsDefault, SessionManager.instance.caloriesDefault);
			
			UpdateDuration();
			
		}
		
		// -------------------------------------------------------------------------------
		// UpdateDuration
		// -------------------------------------------------------------------------------
		public void UpdateDuration()
		{
		
			if (string.IsNullOrWhiteSpace(timestamp))
				timestamp = DateTime.Now.ToString();
				
			if (lastDuration == 0)
				lastDuration = Tools.ConvertToUnixTimestamp(DateTime.UtcNow);
				
			duration = Math.Max(0, Tools.ConvertToUnixTimestamp(DateTime.UtcNow) - lastDuration);
			
		}
		
		// -------------------------------------------------------------------------------
		
	}
	
	// ===================================================================================
	
}

// =======================================================================================
//
//
// =======================================================================================

using System;
using UnityEngine;
using UnityEngine.Events;
using System.Data;
using Mono.Data.Sqlite;
using System.IO;
using System.Collections.Generic;
using wovencode;

namespace wovencode
{
	
	// ===================================================================================
	// SESSION MANAGER
	// ===================================================================================
	[DisallowMultipleComponent]
	public partial class SessionManager : BaseManager
	{
		
		[Header("[SESSION SETTINGS]")]
		public MeasurementSystem 		measurementSystem;
		public float 					resetInterval 					= 21600f;
		public int						maxSessions						= 16;
		public float 					caloriesDefault 				= 3f;
		public int 						stepsDefault 					= 100;
		
		public UnityEvent				resetEvent;
		public UnityEvent				changedEvent;
		
		public static SessionManager 	instance 		= null;
		
		
		protected double dLastTimeSeconds;				// permanent
		
		protected double dNowTimeSeconds;				// temporary
		
		// -------------------------------------------------------------------------------
		// Awake
		// -------------------------------------------------------------------------------
        void Awake() {
            instance = this;
            dNowTimeSeconds 	= Tools.ConvertToUnixTimestamp(DateTime.UtcNow);
            dLastTimeSeconds 	= Tools.ConvertToUnixTimestamp(DateTime.UtcNow);
        }
		
		// =================================== EVENTS ====================================
		
		// -------------------------------------------------------------------------------
		// OnChanged
		// -------------------------------------------------------------------------------
		public override void OnChanged() {
		}
		
		// -------------------------------------------------------------------------------
		// OnUpdate
		// -------------------------------------------------------------------------------
		public override void OnUpdate() {
			OnSave();
		}
		
		// -------------------------------------------------------------------------------
		// OnRefresh
		// -------------------------------------------------------------------------------
		public override void OnRefresh() {
			
			dNowTimeSeconds = Tools.ConvertToUnixTimestamp(DateTime.UtcNow);
			changedEvent.Invoke();
				
			if (dNowTimeSeconds > dLastTimeSeconds + resetInterval)
			{
				OnReset();
			}
			
			dLastTimeSeconds 	= Tools.ConvertToUnixTimestamp(DateTime.UtcNow);
			
		}
		
		// -------------------------------------------------------------------------------
		// OnReset
		// -------------------------------------------------------------------------------
		public override void OnReset() {
			resetEvent.Invoke();
		}
				
		// -------------------------------------------------------------------------------
		// OnLoad
		// -------------------------------------------------------------------------------
		public override void OnLoad() {
			
			List< List<object> > table = DatabaseManager.instance.ExecuteReader("SELECT lastTime FROM data WHERE id=@id", new SqliteParameter("@id", Tools.GetUserId));
			
			if (table.Count == 1)
			{
				List<object> row = table[0];
				dLastTimeSeconds = (float)row[0];
			}
			
		}
		
		// -------------------------------------------------------------------------------
		// OnSave
		// -------------------------------------------------------------------------------
		public override void OnSave() {
			DatabaseManager.instance.ExecuteNonQuery("DELETE FROM data WHERE id=@id", new SqliteParameter("@id", Tools.GetUserId));
			DatabaseManager.instance.ExecuteNonQuery("INSERT INTO data VALUES (@id, @lastTime)",
													new SqliteParameter("@id", Tools.GetUserId),
													new SqliteParameter("@lastTime", Tools.ConvertToUnixTimestamp(DateTime.UtcNow))
													);
		}
		
		// -------------------------------------------------------------------------------
		
	}
}

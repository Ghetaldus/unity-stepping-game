// =======================================================================================
//
//
// =======================================================================================

using System;
using UnityEngine;
using UnityEngine.UI;
using System.Data;
using Mono.Data.Sqlite;
using System.IO;
using wovencode;

namespace wovencode
{
	
	// ===================================================================================
	// UI MANAGER
	// ===================================================================================
	[DisallowMultipleComponent]
	public partial class UiManager : BaseManager
	{
		
		
		public Text totalSteps;
		public Text totalDistance;
		public Text totalCalories;
		public Text totalTime;
		
		
		
		// =================================== EVENTS ====================================
		
		// -------------------------------------------------------------------------------
		// OnChanged
		// -------------------------------------------------------------------------------
		public override void OnChanged() {
		
			totalSteps.text 		= StepManager.instance.stepData.totalSteps.ToString();
			totalDistance.text 		= StepManager.instance.stepData.totalDistance.ToString();
			totalCalories.text 		= StepManager.instance.stepData.totalCalories.ToString();
			totalTime.text 			= StepManager.instance.stepData.totalDuration.ToString();
		
		
			//lastActiveText.text = SessionManager.instance.UpTime.ToString();
			//upTimeText.text = SessionManager.instance.LastActive.ToString();
			
			
		}
		
		// -------------------------------------------------------------------------------
		// OnUpdate
		// -------------------------------------------------------------------------------
		public override void OnUpdate() {
		}
		
		// -------------------------------------------------------------------------------
		// OnRefresh
		// -------------------------------------------------------------------------------
		public override void OnRefresh() {
		}
		
		// -------------------------------------------------------------------------------
		// OnReset
		// -------------------------------------------------------------------------------
		public override void OnReset() {
		}
		
		// -------------------------------------------------------------------------------
		// OnLoad
		// -------------------------------------------------------------------------------
		public override void OnLoad() {
		}
		
		// -------------------------------------------------------------------------------
		// OnSave
		// -------------------------------------------------------------------------------
		public override void OnSave() {
		}
		
		
	}
}
